'use strict';

/**
 * Client interactions for the ShelfDesk demonstration. Authentication is
 * simulated (coursework prototype only), not suitable for real private data.
 */
const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];

const state = { books: [], page: 1, pageSize: 8, busy: false, signedIn: false };
const els = {
  signInView: $('#sign-in-view'), workspace: $('#workspace'), loginForm: $('#login-form'),
  bookForm: $('#book-form'), recordsBody: $('#records-body'), mobileRecords: $('#mobile-record-list'),
  status: $('#status-region'), error: $('#error-region'), search: $('#search'),
  filterStatus: $('#filter-status'), sortBy: $('#sort-by')
};

function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

function announce(message, type = 'success') {
  els.status.replaceChildren();
  const toast = document.createElement('div');
  toast.className = `toast ${type === 'error' ? 'error' : ''}`;
  toast.textContent = message;
  els.status.append(toast);
  if (type === 'error') {
    els.error.textContent = '';
    setTimeout(() => { els.error.textContent = message; }, 0);
  }
}

function setError(field, message) {
  const target = document.getElementById(field);
  const error = document.getElementById(`${field}-error`);
  if (!target || !error) return;
  error.textContent = message;
  if (message) target.setAttribute('aria-invalid', 'true');
  else target.removeAttribute('aria-invalid');
}
function clearFormErrors(form) {
  form.querySelectorAll('[aria-invalid="true"]').forEach(el => el.removeAttribute('aria-invalid'));
  form.querySelectorAll('.field-error').forEach(el => { el.textContent = ''; });
}
function firstInvalid(fields) {
  const el = fields.map(id => document.getElementById(id)).find(item => item?.getAttribute('aria-invalid') === 'true');
  if (el) el.focus();
}

async function fetchJSON(path, options = {}) {
  let response;
  try { response = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...options }); }
  catch { throw new Error('Unable to reach the server. Check your connection.'); }
  let data;
  try { data = await response.json(); }
  catch { throw new Error('The server returned an unexpected response.'); }
  if (!response.ok) throw new Error(data.error || 'This action could not be completed.');
  return data;
}

async function loadBooks({ notify = false } = {}) {
  $('#result-count').textContent = 'Loading books…';
  try {
    const data = await fetchJSON('/api/books');
    state.books = data.books;
    renderDashboard();
    renderRecords();
    if (notify) announce('Book records updated.');
  } catch (err) {
    $('#result-count').textContent = 'Unable to load records.';
    announce(err.message, 'error');
  }
}

function setSignedIn(active, username = '') {
  state.signedIn = active;
  $('.skip-link').href = active ? '#main' : '#login-main';
  els.signInView.hidden = active;
  els.workspace.hidden = !active;
  $('#signed-in-user').textContent = username;
  if (active) {
    renderPage();
    loadBooks();
  } else {
    location.hash = '';
    els.loginForm.reset();
    clearFormErrors(els.loginForm);
    $('#username').focus();
  }
}

els.loginForm.addEventListener('submit', async event => {
  event.preventDefault();
  clearFormErrors(els.loginForm);
  const username = $('#username').value.trim();
  const password = $('#password').value;
  if (!username) setError('username', 'Enter a username to continue.');
  if (!password.trim()) setError('password', 'Enter a password to continue.');
  if (!username || !password.trim()) {
    announce('Please fix the highlighted sign-in fields.', 'error');
    firstInvalid(['username', 'password']);
    return;
  }
  const button = $('#sign-in-button');
  button.disabled = true;
  button.textContent = 'Signing in…';
  announce('Signing in…');
  await wait(550);
  button.disabled = false;
  button.textContent = 'Sign in →';
  sessionStorage.setItem('shelfdesk-demo-user', username);
  setSignedIn(true, username);
  announce(`Signed in as ${username}.`);
});

$('#sign-out').addEventListener('click', () => {
  sessionStorage.removeItem('shelfdesk-demo-user');
  setSignedIn(false);
  announce('You have signed out.');
});

function renderPage() {
  if (!state.signedIn) return;
  const slug = location.hash.replace('#', '');
  const current = ['dashboard', 'add-book', 'records'].includes(slug) ? slug : 'dashboard';
  $$('[data-page]').forEach(page => { page.hidden = page.dataset.page !== current; });
  $$('[data-page-link]').forEach(link => {
    if (link.dataset.pageLink === current) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
  if (current === 'records') renderRecords();
  document.title = `${current === 'dashboard' ? 'Dashboard' : current === 'add-book' ? 'Add a book' : 'Records'} — ShelfDesk`;
  const title = document.querySelector(`#page-${current} h1`);
  if (title) title.focus({ preventScroll: true });
  window.scrollTo({ top: 0, behavior: 'auto' });
}
window.addEventListener('hashchange', renderPage);

function statusNode(status) {
  const span = document.createElement('span');
  span.className = `status-badge ${status === 'loaned' ? 'loaned' : 'available'}`;
  span.textContent = status === 'loaned' ? 'On loan' : 'Available';
  return span;
}
function elt(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function renderDashboard() {
  $('#total-count').textContent = state.books.length.toLocaleString();
  $('#available-count').textContent = state.books.filter(book => book.status === 'available').length.toLocaleString();
  $('#loaned-count').textContent = state.books.filter(book => book.status === 'loaned').length.toLocaleString();
  const list = $('#recent-list');
  list.replaceChildren();
  if (!state.books.length) {
    list.append(elt('li', 'placeholder', 'No books yet. Add the first book to get started.'));
    return;
  }
  [...state.books].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5).forEach(book => {
    const li = elt('li');
    const content = elt('div');
    content.append(elt('span', 'recent-title', book.title), elt('span', 'recent-author', book.author));
    li.append(content, statusNode(book.status));
    list.append(li);
  });
}

function updateLoanFields() {
  const onLoan = $('#loan-status').value === 'loaned';
  const referenceOnly = $('#reference-only').checked;
  $('#loan-fields').hidden = !onLoan;
  $('#borrower').disabled = !onLoan;
  $('#due-date').disabled = !onLoan;
  $('#borrower').required = onLoan;
  $('#due-date').required = onLoan;
  if (referenceOnly && onLoan) {
    setError('loan-status', 'Reference-only books cannot be on loan.');
  } else setError('loan-status', '');
}
$('#loan-status').addEventListener('change', () => {
  updateLoanFields();
  announce($('#loan-status').value === 'loaned' ? 'Loan details fields are now visible.' : 'Loan details fields are now hidden.');
});
$('#reference-only').addEventListener('change', updateLoanFields);

els.bookForm.addEventListener('reset', () => {
  // The reset event fires before the browser has restored default control values.
  setTimeout(() => { clearFormErrors(els.bookForm); updateLoanFields(); }, 0);
});

els.bookForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (state.busy) return;
  clearFormErrors(els.bookForm);
  const payload = {
    title: $('#title').value.trim(), author: $('#author').value.trim(),
    category: $('#category').value, status: $('#loan-status').value,
    condition: els.bookForm.querySelector('input[name="condition"]:checked')?.value || '',
    referenceOnly: $('#reference-only').checked,
    borrower: $('#borrower').value.trim(), dueDate: $('#due-date').value
  };
  const invalid = [];
  if (payload.title.length < 2) { setError('title', 'Enter a book title with at least 2 characters.'); invalid.push('title'); }
  if (payload.author.length < 2) { setError('author', 'Enter an author name with at least 2 characters.'); invalid.push('author'); }
  if (!payload.category) { setError('category', 'Choose a category.'); invalid.push('category'); }
  if (payload.referenceOnly && payload.status === 'loaned') { setError('loan-status', 'Reference-only books cannot be on loan.'); invalid.push('loan-status'); }
  if (payload.status === 'loaned') {
    if (payload.borrower.length < 2) { setError('borrower', 'Enter the borrower’s name.'); invalid.push('borrower'); }
    if (!payload.dueDate) { setError('due-date', 'Choose a due date.'); invalid.push('due-date'); }
  }
  if (invalid.length) {
    announce('Please correct the highlighted fields before saving.', 'error');
    firstInvalid(invalid);
    return;
  }
  state.busy = true;
  const button = $('#save-button');
  button.disabled = true;
  button.textContent = 'Saving…';
  announce('Saving book record…');
  try {
    await fetchJSON('/api/books', { method: 'POST', body: JSON.stringify(payload) });
    els.bookForm.reset();
    clearFormErrors(els.bookForm);
    updateLoanFields();
    await loadBooks();
    announce(`“${payload.title}” was saved successfully.`);
    location.hash = '#records';
  } catch (err) { announce(err.message, 'error'); }
  finally {
    state.busy = false;
    button.disabled = false;
    button.textContent = 'Save book →';
  }
});

function filteredBooks() {
  const search = els.search.value.toLocaleLowerCase().trim();
  const status = els.filterStatus.value;
  const sort = els.sortBy.value;
  const list = state.books.filter(book => {
    return (status === 'all' || book.status === status) &&
      (!search || `${book.title} ${book.author}`.toLocaleLowerCase().includes(search));
  });
  list.sort((a, b) => {
    if (sort === 'title') return a.title.localeCompare(b.title);
    if (sort === 'author') return a.author.localeCompare(b.author);
    return b.createdAt.localeCompare(a.createdAt);
  });
  return list;
}

let selectedLoanBook = null;
let loanOpener = null;

function makeAction(book) {
  const button = elt('button', 'action-button', book.status === 'available' ? 'Mark on loan' : 'Mark returned');
  button.type = 'button';
  button.disabled = Boolean(book.referenceOnly && book.status === 'available');
  button.title = book.referenceOnly ? 'Reference-only books cannot be loaned' : '';
  button.setAttribute('aria-label', `${book.status === 'available' ? 'Mark on loan' : 'Mark returned'}: ${book.title}`);
  button.addEventListener('click', () => {
    if (book.status === 'available') openLoan(book, button);
    else returnBook(book, button);
  });
  return button;
}

function openLoan(book, opener) {
  if (state.busy) return;
  selectedLoanBook = book;
  loanOpener = opener;
  $('#loan-book-title').textContent = book.title;
  $('#loan-form').reset();
  clearFormErrors($('#loan-form'));
  $('#loan-dialog').showModal();
  $('#loan-borrower').focus();
}
function closeLoan() {
  $('#loan-dialog').close();
  if (loanOpener?.isConnected) loanOpener.focus();
  selectedLoanBook = null;
}
$('#cancel-loan').addEventListener('click', closeLoan);
$('#loan-dialog').addEventListener('close', () => { selectedLoanBook = null; });

$('#loan-form').addEventListener('submit', async event => {
  event.preventDefault();
  if (!selectedLoanBook || state.busy) return;
  clearFormErrors($('#loan-form'));
  const borrower = $('#loan-borrower').value.trim();
  const dueDate = $('#loan-due-date').value;
  const invalid = [];
  if (borrower.length < 2) { setError('loan-borrower', 'Enter a borrower name with at least 2 characters.'); invalid.push('loan-borrower'); }
  if (!dueDate) { setError('loan-due-date', 'Choose a due date.'); invalid.push('loan-due-date'); }
  if (invalid.length) {
    announce('Please complete the highlighted loan details.', 'error');
    firstInvalid(invalid);
    return;
  }
  const book = selectedLoanBook;
  state.busy = true;
  $('#confirm-loan').disabled = true;
  $('#confirm-loan').textContent = 'Saving…';
  announce(`Recording loan for “${book.title}”…`);
  try {
    await fetchJSON(`/api/books/${book.id}`, {
      method: 'PATCH', body: JSON.stringify({ status: 'loaned', borrower, dueDate })
    });
    closeLoan();
    await loadBooks();
    announce(`Loan recorded for “${book.title}”.`);
  } catch (err) { announce(err.message, 'error'); }
  finally {
    state.busy = false;
    $('#confirm-loan').disabled = false;
    $('#confirm-loan').textContent = 'Record loan';
  }
});

async function returnBook(book, button) {
  if (state.busy) return;
  state.busy = true;
  button.disabled = true;
  announce(`Updating “${book.title}”…`);
  try {
    await fetchJSON(`/api/books/${book.id}`, {
      method: 'PATCH', body: JSON.stringify({ status: 'available', borrower: '', dueDate: '' })
    });
    await loadBooks();
    announce(`“${book.title}” has been marked returned.`);
  } catch (err) {
    announce(err.message, 'error');
    button.disabled = false;
  } finally { state.busy = false; }
}

function renderRecords() {
  const list = filteredBooks();
  const pages = Math.max(1, Math.ceil(list.length / state.pageSize));
  state.page = Math.min(state.page, pages);
  const pageItems = list.slice((state.page - 1) * state.pageSize, state.page * state.pageSize);
  $('#result-count').textContent = `${list.length} ${list.length === 1 ? 'book' : 'books'} found${list.length !== state.books.length ? ` (of ${state.books.length} total)` : ''}`;
  $('#empty-state').hidden = list.length > 0;
  $('#table-wrap').hidden = !list.length;
  els.mobileRecords.hidden = !list.length;
  $('#pagination').hidden = !list.length;
  els.recordsBody.replaceChildren();
  els.mobileRecords.replaceChildren();
  pageItems.forEach(book => {
    const row = elt('tr');
    const detail = elt('td');
    detail.append(elt('span', 'cell-title', book.title), elt('span', 'cell-subtitle', book.author));
    const category = elt('td', '', book.category);
    const condition = elt('td', '', book.condition);
    const status = elt('td'); status.append(statusNode(book.status));
    const action = elt('td'); action.append(makeAction(book));
    row.append(detail, category, condition, status, action);
    els.recordsBody.append(row);

    const card = elt('li');
    card.append(elt('h2', '', book.title), elt('p', 'cell-subtitle', `by ${book.author}`));
    const data = elt('dl');
    for (const [key, value] of [['Category', book.category], ['Condition', book.condition], ['Status', book.status === 'loaned' ? 'On loan' : 'Available']]) {
      data.append(elt('dt', '', key), elt('dd', '', value));
    }
    card.append(data, makeAction(book));
    els.mobileRecords.append(card);
  });
  $('#page-label').textContent = `Page ${state.page} of ${pages}`;
  $('#previous-page').disabled = state.page === 1;
  $('#next-page').disabled = state.page === pages;
}
function resetPagination() { state.page = 1; renderRecords(); }
[els.search, els.filterStatus, els.sortBy].forEach(control => {
  control.addEventListener(control === els.search ? 'input' : 'change', resetPagination);
});
$('#clear-filters').addEventListener('click', () => {
  els.search.value = '';
  els.filterStatus.value = 'all';
  els.sortBy.value = 'newest';
  resetPagination();
  els.search.focus();
});
$('#previous-page').addEventListener('click', () => { state.page -= 1; renderRecords(); $('#page-label').scrollIntoView({ block: 'nearest' }); });
$('#next-page').addEventListener('click', () => { state.page += 1; renderRecords(); $('#page-label').scrollIntoView({ block: 'nearest' }); });

// Simulated session: deliberately does not protect server endpoints.
const demoUser = sessionStorage.getItem('shelfdesk-demo-user');
if (demoUser) setSignedIn(true, demoUser);
