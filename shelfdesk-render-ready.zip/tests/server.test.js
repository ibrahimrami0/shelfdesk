'use strict';
const { test, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { createAppServer, validateBook } = require('../server');

let server, base, folder;
async function setup() {
  if (server) return;
  folder = await fs.mkdtemp(path.join(os.tmpdir(), 'shelfdesk-test-'));
  server = createAppServer({ dataFile: path.join(folder, 'records.json') });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${server.address().port}`;
}
after(async () => {
  if (server) await new Promise(resolve => server.close(resolve));
  if (folder) await fs.rm(folder, { recursive: true, force: true });
});

const validBook = { title: 'Example Book', author: 'Example Author', category: 'Science', condition: 'Good', status: 'available', referenceOnly: false, borrower: '', dueDate: '' };
test('rejects invalid form fields', () => {
  assert.match(validateBook({ ...validBook, title: 'A' }).error, /Title/);
  assert.match(validateBook({ ...validBook, category: 'Unknown' }).error, /category/);
  assert.match(validateBook({ ...validBook, status: 'loaned' }).error, /Borrower/);
  assert.ok(validateBook(validBook).value);
});
test('loads site and health endpoint', async () => {
  await setup();
  const page = await fetch(base + '/');
  assert.equal(page.status, 200);
  assert.match(await page.text(), /ShelfDesk/);
  const health = await fetch(base + '/api/health');
  assert.deepEqual(await health.json(), { ok: true });
});
test('creates, persists, and retrieves records', async () => {
  await setup();
  const created = await fetch(base + '/api/books', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(validBook) });
  assert.equal(created.status, 201);
  const data = await created.json();
  assert.equal(data.book.title, 'Example Book');
  const records = await fetch(base + '/api/books');
  assert.equal((await records.json()).books.length, 1);
  const stored = JSON.parse(await fs.readFile(path.join(folder, 'records.json'), 'utf8'));
  assert.equal(stored.length, 1);
});
test('can loan and return a book', async () => {
  await setup();
  const records = await (await fetch(base + '/api/books')).json();
  const id = records.books[0].id;
  const loan = await fetch(base + '/api/books/' + id, { method: 'PATCH', headers:{'Content-Type':'application/json'}, body:JSON.stringify({status:'loaned',borrower:'Demo Patron',dueDate:'2026-12-01'}) });
  assert.equal(loan.status, 200);
  assert.equal((await loan.json()).book.status, 'loaned');
  const returned = await fetch(base + '/api/books/' + id, { method: 'PATCH', headers:{'Content-Type':'application/json'}, body:JSON.stringify({status:'available',borrower:'',dueDate:''}) });
  assert.equal(returned.status, 200);
  assert.equal((await returned.json()).book.status, 'available');
});
test('rejects illegal input and unknown resources', async () => {
  await setup();
  const invalid = await fetch(base + '/api/books', { method:'POST', headers:{'Content-Type':'application/json'},body:JSON.stringify({ ...validBook, title:'' }) });
  assert.equal(invalid.status, 400);
  const missing = await fetch(base + '/does-not-exist');
  assert.equal(missing.status, 404);
});
